export const BACKEND_URL = "https://tidytabs-ai.onrender.com";
